# مترجم GTA للتابلت

يقرأ ترجمة اللعبة من صورة USB Camera Pro على الشاشة ويعرض ترجمتها العربية فوقها.
ملاحظة: خط Changa تحت رخصة SIL OFL (FONT-LICENSE-Changa.txt). فكرة المناطق وأماكنها مأخوذة من مشروع VI Translator (رخصة MIT).
