plugins {
    id("com.android.application")
}

android {
    namespace = "app.gtasubs"
    compileSdk = 36

    defaultConfig {
        applicationId = "app.gtasubs"
        minSdk = 26
        // 35 on purpose: Android 16 ignores the landscape lock for apps that target 36 on tablets
        targetSdk = 35
        versionCode = 2
        versionName = "0.2.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    // OCR on the device (English / Latin), model bundled in the app
    implementation("com.google.mlkit:text-recognition:16.0.1")
    // English -> Arabic translation on the device (the model downloads once, ~30 MB)
    implementation("com.google.mlkit:translate:17.0.3")
}
