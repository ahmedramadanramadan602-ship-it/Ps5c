package app.gtasubs

import android.content.Context
import android.graphics.Rect
import android.os.Build
import android.util.DisplayMetrics
import android.view.WindowManager

/**
 * A place of the game picture that is read, and where its Arabic goes. All numbers are fractions
 * (0..1) of the game picture (not of the tablet screen), the same idea as the PC app's read areas.
 */
data class AreaDef(
    val id: String,
    val label: String,
    // where the English is read
    val x: Float, val y: Float, val w: Float, val h: Float,
    // where the Arabic is drawn (fixed areas)
    val outX: Float, val outY: Float, val outW: Float, val outH: Float,
    /** draw the Arabic right under the English text that was found, not in a fixed place */
    val under: Boolean,
    /** only read lines centred in the picture (subtitles are) */
    val centeredOnly: Boolean,
    /** dark see-through box behind the Arabic, like the game's own instructions box */
    val darkBox: Boolean,
    val sizeScale: Float,
)

object Areas {
    // A starting guess taken from the PC app's GTA VI profile: calibrate on the real picture.
    val all = listOf(
        AreaDef(
            "subtitles", "الحوار (الترجمة اللي تحت)",
            0.10f, 0.80f, 0.80f, 0.118f,
            0.10f, 0.555f, 0.80f, 0.20f,
            under = false, centeredOnly = true, darkBox = false, sizeScale = 1.0f,
        ),
        AreaDef(
            "instructions", "التعليمات (آخر الشاشة)",
            0.20f, 0.935f, 0.60f, 0.06f,
            0.10f, 0.76f, 0.80f, 0.04f,
            under = false, centeredOnly = true, darkBox = false, sizeScale = 0.92f,
        ),
        AreaDef(
            "help", "التعليمات (فوق شمال)",
            0.01f, 0.18f, 0.30f, 0.20f,
            0f, 0f, 0.30f, 0f,
            under = true, centeredOnly = false, darkBox = true, sizeScale = 0.92f,
        ),
    )
}

object Geo {
    /** The tablet screen in pixels, always landscape (width >= height). */
    fun screen(ctx: Context): Pair<Int, Int> {
        val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val w: Int
        val h: Int
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.maximumWindowMetrics.bounds
            w = b.width()
            h = b.height()
        } else {
            val m = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(m)
            w = m.widthPixels
            h = m.heightPixels
        }
        return maxOf(w, h) to minOf(w, h)
    }

    /**
     * Where the game picture is on the screen. aspect 0: 16:9 centred (black bars on a 16:10
     * tablet), 1: the picture fills the whole screen.
     */
    fun video(w: Int, h: Int, aspect: Int): Rect {
        if (aspect == 1) return Rect(0, 0, w, h)
        val ar = 16f / 9f
        return if (w.toFloat() / h > ar) {
            val vw = (h * ar).toInt()
            val x = (w - vw) / 2
            Rect(x, 0, x + vw, h)
        } else {
            val vh = (w / ar).toInt()
            val y = (h - vh) / 2
            Rect(0, y, w, y + vh)
        }
    }
}
