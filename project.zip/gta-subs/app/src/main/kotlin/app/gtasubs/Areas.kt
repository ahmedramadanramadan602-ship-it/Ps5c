package app.gtasubs

import android.content.Context
import android.graphics.Rect
import android.os.Build
import android.util.DisplayMetrics
import android.view.WindowManager
import org.json.JSONArray
import org.json.JSONObject

/**
 * A place of the game picture that is read, and where its Arabic goes. All numbers are fractions
 * (0..1) of the game picture (not of the tablet screen).
 */
data class AreaDef(
    val id: String,
    val label: String,
    // where the English is read
    val x: Float, val y: Float, val w: Float, val h: Float,
    // where the Arabic is drawn when placement is 0
    val outX: Float, val outY: Float, val outW: Float, val outH: Float,
    /** 0: the fixed rectangle above, 1: right under the English that was found, 2: right above it */
    val placement: Int,
    /** only read lines centred in the picture (subtitles are) */
    val centeredOnly: Boolean,
    /** dark see-through box behind the Arabic, like the game's own instructions box */
    val darkBox: Boolean,
    val sizeScale: Float,
)

object Areas {
    // A starting guess taken from the PC app's GTA VI profile: calibrate it with the editor.
    fun defaults(): List<AreaDef> = listOf(
        AreaDef(
            "subtitles", "الحوار (الترجمة اللي تحت)",
            0.10f, 0.80f, 0.80f, 0.118f,
            0.10f, 0.555f, 0.80f, 0.20f,
            placement = 0, centeredOnly = true, darkBox = false, sizeScale = 1.0f,
        ),
        AreaDef(
            "instructions", "التعليمات (آخر الشاشة)",
            0.20f, 0.935f, 0.60f, 0.06f,
            0.10f, 0.76f, 0.80f, 0.04f,
            placement = 0, centeredOnly = true, darkBox = false, sizeScale = 0.92f,
        ),
        AreaDef(
            "help", "التعليمات (فوق شمال)",
            0.01f, 0.18f, 0.30f, 0.20f,
            0.01f, 0.40f, 0.30f, 0.10f,
            placement = 1, centeredOnly = false, darkBox = true, sizeScale = 0.92f,
        ),
    )

    fun load(p: Prefs): List<AreaDef> {
        val s = p.areasJson ?: return defaults()
        return try {
            val arr = JSONArray(s)
            val out = ArrayList<AreaDef>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(
                    AreaDef(
                        o.getString("id"), o.getString("label"),
                        f(o, "x"), f(o, "y"), f(o, "w"), f(o, "h"),
                        f(o, "ox"), f(o, "oy"), f(o, "ow"), f(o, "oh"),
                        o.getInt("pl"), o.getBoolean("ce"), o.getBoolean("bx"), f(o, "sc"),
                    ),
                )
            }
            if (out.isEmpty()) defaults() else out
        } catch (e: Exception) {
            defaults()
        }
    }

    private fun f(o: JSONObject, k: String): Float = o.getDouble(k).toFloat()

    fun save(p: Prefs, list: List<AreaDef>) {
        val arr = JSONArray()
        for (a in list) {
            val o = JSONObject()
            o.put("id", a.id)
            o.put("label", a.label)
            o.put("x", a.x.toDouble())
            o.put("y", a.y.toDouble())
            o.put("w", a.w.toDouble())
            o.put("h", a.h.toDouble())
            o.put("ox", a.outX.toDouble())
            o.put("oy", a.outY.toDouble())
            o.put("ow", a.outW.toDouble())
            o.put("oh", a.outH.toDouble())
            o.put("pl", a.placement)
            o.put("ce", a.centeredOnly)
            o.put("bx", a.darkBox)
            o.put("sc", a.sizeScale.toDouble())
            arr.put(o)
        }
        p.areasJson = arr.toString()
        p.areasVersion = p.areasVersion + 1
    }

    fun reset(p: Prefs) {
        p.areasJson = null
        p.areasVersion = p.areasVersion + 1
    }
}

object Geo {
    /** The tablet screen in pixels, always landscape (width >= height). */
    fun screen(ctx: Context): Pair<Int, Int> {
        val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val w: Int
        val h: Int
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.maximumWindowMetrics.bounds
            w = b.width()
            h = b.height()
        } else {
            val m = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(m)
            w = m.widthPixels
            h = m.heightPixels
        }
        return maxOf(w, h) to minOf(w, h)
    }

    /**
     * Where the game picture is on the screen. aspect 0: 16:9 centred (black bars on a 16:10
     * tablet), 1: the picture fills the whole screen.
     */
    fun video(w: Int, h: Int, aspect: Int): Rect {
        if (aspect == 1) return Rect(0, 0, w, h)
        val ar = 16f / 9f
        return if (w.toFloat() / h > ar) {
            val vw = (h * ar).toInt()
            val x = (w - vw) / 2
            Rect(x, 0, x + vw, h)
        } else {
            val vh = (w / ar).toInt()
            val y = (h - vh) / 2
            Rect(0, y, w, y + vh)
        }
    }

    /** The same, also knowing the custom rectangle from the editor (aspect 2). */
    fun video(w: Int, h: Int, p: Prefs): Rect {
        if (p.aspect == 2) {
            val r = p.videoRect
            if (r != null) {
                val rect = Rect((r[0] * w).toInt(), (r[1] * h).toInt(), (r[2] * w).toInt(), (r[3] * h).toInt())
                if (rect.width() > 100 && rect.height() > 60) return rect
            }
            return video(w, h, 0)
        }
        return video(w, h, p.aspect)
    }
}
