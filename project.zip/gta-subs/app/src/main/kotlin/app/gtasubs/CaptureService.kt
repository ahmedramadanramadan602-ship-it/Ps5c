package app.gtasubs

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.nio.ByteBuffer
import java.util.concurrent.TimeUnit
import kotlin.math.abs

/**
 * Looks at the tablet's screen (where USB Camera Pro shows the game), reads the English in the
 * game's subtitle places, translates it on the device and draws the Arabic over it.
 */
class CaptureService : Service() {
    private val main = Handler(Looper.getMainLooper())
    private var worker: HandlerThread? = null
    private var h: Handler? = null
    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var overlay: OverlayManager? = null
    private var recognizer: TextRecognizer? = null
    private var translator: Translator? = null
    private lateinit var prefs: Prefs

    @Volatile
    private var alive = false
    private var capW = 0
    private var capH = 0
    private var frame: Bitmap? = null
    private var frameCanvas: Canvas? = null
    private val black = Paint().apply { color = Color.BLACK }
    private val hs = IntArray(32 * 8)

    private class AreaState {
        var hash = 0
        var pending = ""
        var shown = ""
        var empty = 0
    }

    private class Line(val text: String, val rect: Rect)

    private val states = HashMap<String, AreaState>()
    private val cache = LinkedHashMap<String, String>()

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            main.post { stopSelf() }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null || intent.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (alive) return START_NOT_STICKY
        prefs = Prefs(this)
        startFg()

        val code = intent.getIntExtra(EXTRA_CODE, 0)
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra(EXTRA_DATA)
        }
        if (data == null) {
            Status.set("مفيش إذن تصوير الشاشة، جرّب تاني")
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val p = mpm.getMediaProjection(code, data)
            projection = p
            alive = true
            Status.setRunning(true)
            val t = HandlerThread("gtasubs").also { it.start() }
            worker = t
            val hh = Handler(t.looper)
            h = hh
            overlay = OverlayManager(applicationContext)
            startCapture(p, hh)
            hh.post { prepare() }
        } catch (e: Exception) {
            Status.set("فشل بدء التصوير: ${e.message}")
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "مترجم GTA", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(
            this, 1, Intent(this, CaptureService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE,
        )
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notify)
            .setContentTitle("مترجم GTA شغال")
            .setContentText("اضغط لفتح التطبيق")
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_notify), "إيقاف", stop).build())
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, n)
        }
    }

    private fun startCapture(p: MediaProjection, hh: Handler) {
        val (w, hgt) = Geo.screen(this)
        capW = w
        capH = hgt
        // (Android 14 and later want the callback registered before the display is made)
        p.registerCallback(projectionCallback, hh)
        val r = ImageReader.newInstance(w, hgt, PixelFormat.RGBA_8888, 2)
        reader = r
        vd = p.createVirtualDisplay(
            "gtasubs", w, hgt, resources.displayMetrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, hh,
        )
    }

    /** On the worker thread: the OCR and the translation model, then the loop. */
    private fun prepare() {
        try {
            recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            val tr = Translation.getClient(
                TranslatorOptions.Builder()
                    .setSourceLanguage(TranslateLanguage.ENGLISH)
                    .setTargetLanguage(TranslateLanguage.ARABIC)
                    .build(),
            )
            translator = tr
            Status.set("بجهّز نموذج الترجمة (أول مرة بس ومحتاج إنترنت)…")
            Tasks.await(tr.downloadModelIfNeeded(DownloadConditions.Builder().build()), 15, TimeUnit.MINUTES)
        } catch (e: Exception) {
            Status.set("نموذج الترجمة ما نزلش، اتأكد من الإنترنت: ${e.message}")
            main.post { stopSelf() }
            return
        }
        Status.set("شغال، افتح USB Camera Pro")
        tick()
    }

    private fun tick() {
        if (!alive) return
        val t0 = SystemClock.elapsedRealtime()
        try {
            step()
        } catch (e: Throwable) {
            Status.set("خطأ: ${e.javaClass.simpleName}: ${e.message}")
        }
        val dt = SystemClock.elapsedRealtime() - t0
        h?.postDelayed({ tick() }, maxOf(60L, TICK_MS - dt))
    }

    private fun step() {
        val img = reader?.acquireLatestImage() ?: return
        val f: Bitmap
        try {
            val plane = img.planes[0]
            val bw = plane.rowStride / plane.pixelStride
            var fr = frame
            if (fr == null || fr.width != bw || fr.height != img.height) {
                fr = Bitmap.createBitmap(bw, img.height, Bitmap.Config.ARGB_8888)
                frame = fr
                frameCanvas = Canvas(fr)
            }
            val buf = plane.buffer
            val need = bw * 4 * img.height
            if (buf.remaining() >= need) {
                fr.copyPixelsFromBuffer(buf)
            } else {
                val tmp = ByteBuffer.allocateDirect(need)
                tmp.put(buf)
                tmp.rewind()
                fr.copyPixelsFromBuffer(tmp)
            }
            f = fr
        } finally {
            img.close()
        }

        // what this app drew itself is painted black first, so the Arabic is never read as English
        val ov = overlay ?: return
        frameCanvas?.let { c -> ov.visibleRects().forEach { c.drawRect(it, black) } }

        val vr = Geo.video(capW, capH, prefs.aspect)
        for (a in Areas.all) {
            if (!alive) return
            if (prefs.areaOn(a.id)) area(a, vr, f, ov) else ov.clear(a.id)
        }
    }

    private fun area(a: AreaDef, vr: Rect, f: Bitmap, ov: OverlayManager) {
        val cx = (vr.left + a.x * vr.width()).toInt().coerceIn(0, capW - 1)
        val cy = (vr.top + a.y * vr.height()).toInt().coerceIn(0, capH - 1)
        val cw = minOf((a.w * vr.width()).toInt(), capW - cx)
        val ch = minOf((a.h * vr.height()).toInt(), capH - cy)
        if (cw < 16 || ch < 8) return
        val st = states.getOrPut(a.id) { AreaState() }

        val crop = Bitmap.createBitmap(f, cx, cy, cw, ch)
        val hash = quickHash(crop)
        if (hash == st.hash && st.pending == st.shown) {
            crop.recycle()
            return
        }
        st.hash = hash

        val res = Tasks.await(recognizer!!.process(InputImage.fromBitmap(crop, 0)))
        crop.recycle()

        val kept = ArrayList<Line>()
        for (b in res.textBlocks) for (l in b.lines) {
            val r = l.boundingBox ?: continue
            if (a.centeredOnly && abs(r.exactCenterX() / cw - 0.5f) > 0.18f) continue
            kept.add(Line(l.text, r))
        }
        kept.sortBy { it.rect.top }
        val text = kept.joinToString(" ") { it.text }.replace(Regex("\\s+"), " ").trim()
        val norm = Txt.norm(text)

        if (norm.length < 3 || !Txt.latinOk(text)) {
            st.empty++
            if (st.empty >= 2 && (st.shown.isNotEmpty() || st.pending.isNotEmpty())) {
                ov.clear(a.id)
                st.shown = ""
                st.pending = ""
            }
            return
        }
        st.empty = 0
        Status.seen("${a.label}: $text")

        // the same text twice in a row: the line is fully on screen (not fading in)
        if (st.pending.isNotEmpty() && Txt.same(norm, st.pending)) {
            if (st.shown.isEmpty() || !Txt.same(norm, st.shown)) {
                val ar = cache[norm] ?: Tasks.await(translator!!.translate(text)).also {
                    if (cache.size > 300) cache.clear()
                    cache[norm] = it
                }
                if (!alive) return
                val lh = kept.map { it.rect.height() }.average().toFloat()
                val size = (lh * 0.9f * a.sizeScale * prefs.fontScale)
                    .coerceIn(vr.height() * 0.018f, vr.height() * 0.07f)
                if (a.under) {
                    val minL = kept.minOf { it.rect.left }
                    val maxR = kept.maxOf { it.rect.right }
                    val maxB = kept.maxOf { it.rect.bottom }
                    val w = maxOf(maxR - minL + 16, (vr.width() * 0.16f).toInt())
                    ov.showUnder(a, vr, cx + minL - 8, cy + maxB + 6, w, ar, size)
                } else {
                    ov.showFixed(a, vr, ar, size)
                }
                st.shown = norm
            }
            st.pending = st.shown
        } else {
            st.pending = norm
        }
    }

    /** A rough fingerprint of the picture, to skip reading a place that didn't change. */
    private fun quickHash(b: Bitmap): Int {
        val s = Bitmap.createScaledBitmap(b, 32, 8, true)
        s.getPixels(hs, 0, 32, 0, 0, 32, 8)
        if (s !== b) s.recycle()
        var x = 17
        for (p in hs) x = x * 31 + ((p ushr 5) and 0x070707)
        return x
    }

    override fun onDestroy() {
        alive = false
        h?.removeCallbacksAndMessages(null)
        overlay?.clearAll()
        try {
            vd?.release()
        } catch (ignored: Exception) {
        }
        try {
            reader?.close()
        } catch (ignored: Exception) {
        }
        try {
            projection?.unregisterCallback(projectionCallback)
            projection?.stop()
        } catch (ignored: Exception) {
        }
        try {
            recognizer?.close()
            translator?.close()
        } catch (ignored: Exception) {
        }
        worker?.quitSafely()
        Status.setRunning(false)
        Status.set("متوقف")
        super.onDestroy()
    }

    companion object {
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        const val ACTION_STOP = "app.gtasubs.STOP"
        private const val CHANNEL = "cap"

        /** how often the screen is looked at */
        private const val TICK_MS = 450L
    }
}
