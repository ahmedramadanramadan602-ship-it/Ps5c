package app.gtasubs

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONObject
import java.io.File
import java.nio.ByteBuffer
import java.util.Collections
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.math.abs

/**
 * Looks at the tablet's screen (where USB Camera Pro shows the game), reads the English in the
 * places you set, translates it and draws the Arabic over it.
 */
class CaptureService : Service() {
    private val main = Handler(Looper.getMainLooper())
    private var worker: HandlerThread? = null
    private var h: Handler? = null
    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var overlay: OverlayManager? = null
    private var recognizer: TextRecognizer? = null
    private var translator: Translator? = null
    private var control: FloatingControl? = null
    private var awake: AwakeWindow? = null
    private var editor: Editor? = null
    private lateinit var prefs: Prefs

    @Volatile private var alive = false
    @Volatile private var paused = false
    @Volatile private var editing = false
    private var wasIdle = false
    private var controlShown = false
    private var awakeOn = false

    private var capW = 0
    private var capH = 0
    private var frame: Bitmap? = null
    private var frameCanvas: Canvas? = null
    private val black = Paint().apply { color = Color.BLACK }
    private val hs = IntArray(32 * 8)
    private val boostPaint = Paint(Paint.FILTER_BITMAP_FLAG).apply {
        colorFilter = ColorMatrixColorFilter(
            ColorMatrix(
                floatArrayOf(
                    1.35f, 0f, 0f, 0f, -45f,
                    0f, 1.35f, 0f, 0f, -45f,
                    0f, 0f, 1.35f, 0f, -45f,
                    0f, 0f, 0f, 1f, 0f,
                ),
            ),
        )
    }

    private class AreaState {
        var hash = 0
        var pending = ""
        @Volatile var shown = ""
        var empty = 0
    }

    private class Line(val text: String, val rect: Rect)
    private class FsBlock(val norm: String, val text: String, val rect: Rect, val lineH: Float)

    private var areas: List<AreaDef> = emptyList()
    private var areasVer = -1
    private val states = ConcurrentHashMap<String, AreaState>()

    private val offCache = Collections.synchronizedMap(LinkedHashMap<String, String>())
    private val aiCache = Collections.synchronizedMap(LinkedHashMap<String, String>())
    private val recent = ArrayList<String>()
    private val aiPool: ExecutorService = Executors.newFixedThreadPool(2)
    private var cacheDirty = 0

    // the whole-screen mode
    @Volatile private var fsShown = false
    @Volatile private var fsToggle = 0 // 1: show now, 2: hide now
    @Volatile private var fsGen = 0
    private var fsBase: IntArray? = null
    private var fsPrev: IntArray? = null
    private var fsStable = 0
    private var fsHoldUntil = 0L
    private val fpBmp = Bitmap.createBitmap(48, 27, Bitmap.Config.ARGB_8888)
    private val fpCanvas = Canvas(fpBmp)
    private val fpPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val fpPix = IntArray(48 * 27)

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            main.post { stopSelf() }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null || intent.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (intent.action == ACTION_EDIT) {
            if (alive) main.post { openEditor() } else stopSelf()
            return START_NOT_STICKY
        }
        if (alive) return START_NOT_STICKY
        prefs = Prefs(this)
        startFg()

        val code = intent.getIntExtra(EXTRA_CODE, 0)
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra(EXTRA_DATA)
        }
        if (data == null) {
            Status.set("مفيش إذن تصوير الشاشة، جرّب تاني")
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val p = mpm.getMediaProjection(code, data) ?: throw IllegalStateException("no projection")
            projection = p
            alive = true
            Status.markRunning(true)
            val t = HandlerThread("gtasubs").also { it.start() }
            worker = t
            val hh = Handler(t.looper)
            h = hh
            overlay = OverlayManager(applicationContext)
            control = FloatingControl(
                applicationContext,
                onToggle = { togglePause() },
                onSnapshot = { fsToggle = if (fsShown) 2 else 1 },
                onEdit = { openEditor() },
                onOpen = {
                    startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                },
            )
            awake = AwakeWindow(applicationContext)
            startCapture(p, hh)
            hh.post { prepare() }
        } catch (e: Exception) {
            Status.set("فشل بدء التصوير: ${e.message}")
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "مترجم GTA", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(
            this, 1, Intent(this, CaptureService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE,
        )
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notify)
            .setContentTitle("مترجم GTA شغال")
            .setContentText("اضغط لفتح التطبيق")
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_notify), "إيقاف", stop).build())
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, n)
        }
    }

    private fun startCapture(p: MediaProjection, hh: Handler) {
        val (w, hgt) = Geo.screen(this)
        capW = w
        capH = hgt
        // (Android 14 and later want the callback registered before the display is made)
        p.registerCallback(projectionCallback, hh)
        val r = ImageReader.newInstance(w, hgt, PixelFormat.RGBA_8888, 2)
        reader = r
        vd = p.createVirtualDisplay(
            "gtasubs", w, hgt, resources.displayMetrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, hh,
        )
    }

    private fun togglePause() {
        paused = !paused
        control?.setPaused(paused)
        Status.set(if (paused) "الترجمة واقفة مؤقتاً" else "شغال")
    }

    private fun openEditor() {
        if (editing || !alive) return
        editing = true
        val e = Editor(this, prefs, capW, capH) {
            editing = false
            areasVer = -1
        }
        editor = e
        e.show()
    }

    /** Shows or hides the floating button and the keep-awake window to match the settings. */
    private fun syncWindows() {
        val wantC = prefs.floatBtn
        if (wantC != controlShown) {
            controlShown = wantC
            main.post { if (wantC) control?.show() else control?.hide() }
        }
        val wantA = prefs.keepOn
        if (wantA != awakeOn) {
            awakeOn = wantA
            main.post { if (wantA) awake?.on() else awake?.off() }
        }
    }

    /** On the worker thread: the OCR and the translation model, then the loop. */
    private fun prepare() {
        loadCache()
        syncWindows()
        try {
            recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            val tr = Translation.getClient(
                TranslatorOptions.Builder()
                    .setSourceLanguage(TranslateLanguage.ENGLISH)
                    .setTargetLanguage(TranslateLanguage.ARABIC)
                    .build(),
            )
            translator = tr
            Status.set("بجهّز نموذج الترجمة (أول مرة بس ومحتاج إنترنت)…")
            Tasks.await(tr.downloadModelIfNeeded(DownloadConditions.Builder().build()), 15, TimeUnit.MINUTES)
        } catch (e: Exception) {
            Status.set("نموذج الترجمة ما نزلش، اتأكد من الإنترنت: ${e.message}")
            main.post { stopSelf() }
            return
        }
        Status.set("شغال، افتح USB Camera Pro")
        tick()
    }

    private fun tick() {
        if (!alive) return
        val t0 = SystemClock.elapsedRealtime()
        try {
            syncWindows()
            step()
        } catch (e: Throwable) {
            Status.set("خطأ: ${e.javaClass.simpleName}: ${e.message}")
        }
        val dt = SystemClock.elapsedRealtime() - t0
        val every = if (prefs.fast) 250L else 450L
        h?.postDelayed({ tick() }, maxOf(60L, every - dt))
    }

    private fun clearAllState() {
        overlay?.clearAll()
        states.clear()
        fsShown = false
        fsBase = null
        fsPrev = null
        fsStable = 0
        fsGen++
    }

    private fun step() {
        if (paused || editing) {
            if (!wasIdle) {
                wasIdle = true
                clearAllState()
            }
            reader?.acquireLatestImage()?.close()
            return
        }
        wasIdle = false

        val img = reader?.acquireLatestImage() ?: return
        val f: Bitmap
        try {
            val plane = img.planes[0]
            val bw = plane.rowStride / plane.pixelStride
            var fr = frame
            if (fr == null || fr.width != bw || fr.height != img.height) {
                fr = Bitmap.createBitmap(bw, img.height, Bitmap.Config.ARGB_8888)
                frame = fr
                frameCanvas = Canvas(fr)
            }
            val buf = plane.buffer
            val need = bw * 4 * img.height
            if (buf.remaining() >= need) {
                fr.copyPixelsFromBuffer(buf)
            } else {
                val tmp = ByteBuffer.allocateDirect(need)
                tmp.put(buf)
                tmp.rewind()
                fr.copyPixelsFromBuffer(tmp)
            }
            f = fr
        } finally {
            img.close()
        }

        // what this app drew itself is painted black first, so the Arabic is never read as English
        val ov = overlay ?: return
        frameCanvas?.let { c -> ov.visibleRects().forEach { c.drawRect(it, black) } }

        val vr = Geo.video(capW, capH, prefs)
        if (prefs.areasVersion != areasVer) {
            areas = Areas.load(prefs)
            areasVer = prefs.areasVersion
            states.clear()
            ov.clearAll()
            clearFs(ov)
        }
        if (fsToggle == 2) {
            fsToggle = 0
            clearFs(ov)
        }
        for (a in areas) {
            if (!alive) return
            if (prefs.areaOn(a.id)) area(a, vr, f, ov) else ov.clear(a.id)
        }
        if (prefs.scope == 1 || fsShown || fsToggle == 1) fullScreen(f, vr, ov)
    }

    // ---------------------------------------------------------------- the places you set

    private fun area(a: AreaDef, vr: Rect, f: Bitmap, ov: OverlayManager) {
        val cx = (vr.left + a.x * vr.width()).toInt().coerceIn(0, capW - 1)
        val cy = (vr.top + a.y * vr.height()).toInt().coerceIn(0, capH - 1)
        val cw = minOf((a.w * vr.width()).toInt(), capW - cx)
        val ch = minOf((a.h * vr.height()).toInt(), capH - cy)
        if (cw < 16 || ch < 8) return
        val st = states.getOrPut(a.id) { AreaState() }

        val crop = Bitmap.createBitmap(f, cx, cy, cw, ch)
        val hash = quickHash(crop)
        if (hash == st.hash && st.pending == st.shown) {
            crop.recycle()
            return
        }
        st.hash = hash

        val k = if (prefs.boost) 1.5f else 1f
        val src = if (k > 1f) boostBitmap(crop, k) else crop
        val res = Tasks.await(recognizer!!.process(InputImage.fromBitmap(src, 0)))
        if (src !== crop) src.recycle()
        crop.recycle()

        val kept = ArrayList<Line>()
        for (b in res.textBlocks) for (l in b.lines) {
            val r0 = l.boundingBox ?: continue
            val r = Rect((r0.left / k).toInt(), (r0.top / k).toInt(), (r0.right / k).toInt(), (r0.bottom / k).toInt())
            if (a.centeredOnly && abs(r.exactCenterX() / cw - 0.5f) > 0.18f) continue
            kept.add(Line(l.text, r))
        }
        kept.sortBy { it.rect.top }
        val text = kept.joinToString(" ") { it.text }.replace(Regex("\\s+"), " ").trim()
        val norm = Txt.norm(text)

        if (norm.length < 3 || !Txt.latinOk(text)) {
            st.empty++
            if (st.empty >= 2 && (st.shown.isNotEmpty() || st.pending.isNotEmpty())) {
                ov.clear(a.id)
                st.shown = ""
                st.pending = ""
            }
            return
        }
        st.empty = 0
        Status.seen("${a.label}: $text")

        // normally the same text twice in a row (the line is fully on screen, not fading in);
        // the fast mode shows on the first read and fixes it if the next read differs
        if (prefs.fast || (st.pending.isNotEmpty() && Txt.same(norm, st.pending))) {
            if (st.shown.isEmpty() || !Txt.same(norm, st.shown)) {
                st.shown = norm
                val lh = kept.map { it.rect.height() }.average().toFloat()
                val size = (lh * 0.9f * a.sizeScale * prefs.fontScale)
                    .coerceIn(vr.height() * 0.018f, vr.height() * 0.07f)
                val minL = kept.minOf { it.rect.left }
                val maxR = kept.maxOf { it.rect.right }
                val minT = kept.minOf { it.rect.top }
                val maxB = kept.maxOf { it.rect.bottom }
                val ctxLines: List<String> = if (a.centeredOnly) ArrayList(recent) else emptyList()
                if (a.centeredOnly) {
                    recent.add(text)
                    while (recent.size > 3) recent.removeAt(0)
                }
                val style = Style(prefs.fontColor, prefs.strokeScale, a.darkBox || prefs.textBg, if (a.darkBox) 0xB3 else 0x99)
                val render: (String) -> Unit = { ar ->
                    drawArea(ov, a, vr, ar, size, style, cx, cy, minL, maxR, minT, maxB)
                }
                translateThen(norm, text, ctxLines, { states[a.id]?.shown == norm }, render)
            }
            st.pending = st.shown
        } else {
            st.pending = norm
        }
    }

    private fun drawArea(
        ov: OverlayManager, a: AreaDef, vr: Rect, ar: String, size: Float, style: Style,
        cx: Int, cy: Int, minL: Int, maxR: Int, minT: Int, maxB: Int,
    ) {
        when (a.placement) {
            0 -> {
                val x = vr.left + (a.outX * vr.width()).toInt()
                val w = (a.outW * vr.width()).toInt()
                val bottom = vr.top + ((a.outY + a.outH) * vr.height()).toInt()
                ov.show(a.id, ar, x, w, bottom, true, maxOf(40, (a.outH * vr.height()).toInt()), 0, size, true, style)
            }
            1 -> {
                val w = maxOf(maxR - minL + 16, (vr.width() * 0.16f).toInt())
                ov.show(a.id, ar, cx + minL - 8, w, cy + maxB + 6, false, (vr.height() * 0.25f).toInt(), 0, size, a.centeredOnly, style)
            }
            else -> {
                val w = maxOf(maxR - minL + 16, (vr.width() * 0.16f).toInt())
                ov.show(a.id, ar, cx + minL - 8, w, cy + minT - 6, true, (vr.height() * 0.25f).toInt(), 0, size, a.centeredOnly, style)
            }
        }
    }

    // ---------------------------------------------------------------- whole screen

    private fun fingerprint(f: Bitmap, vr: Rect): IntArray {
        val src = Rect(maxOf(0, vr.left), maxOf(0, vr.top), minOf(vr.right, f.width), minOf(vr.bottom, f.height))
        fpCanvas.drawBitmap(f, src, Rect(0, 0, 48, 27), fpPaint)
        fpBmp.getPixels(fpPix, 0, 48, 0, 0, 48, 27)
        val out = IntArray(48 * 27)
        for (i in out.indices) {
            val p = fpPix[i]
            out[i] = (((p shr 16) and 255) * 3 + ((p shr 8) and 255) * 6 + (p and 255)) / 10
        }
        return out
    }

    private fun diffRatio(a: IntArray, b: IntArray): Float {
        var n = 0
        for (i in a.indices) if (abs(a[i] - b[i]) > 24) n++
        return n.toFloat() / a.size
    }

    private fun clearFs(ov: OverlayManager) {
        ov.clearPrefix("f")
        fsShown = false
        fsBase = null
        fsPrev = null
        fsStable = 0
        fsGen++
    }

    /**
     * The whole screen is translated when the picture holds still (menus, maps, pause screens)
     * and goes away when the picture changes. The button in the menu forces it for 8 seconds.
     */
    private fun fullScreen(f: Bitmap, vr: Rect, ov: OverlayManager) {
        val now = SystemClock.elapsedRealtime()
        val fp = fingerprint(f, vr)
        if (fsShown) {
            val base = fsBase
            if (base == null) {
                fsBase = fp
                return
            }
            if (now >= fsHoldUntil && diffRatio(fp, base) > 0.25f) clearFs(ov)
            return
        }
        if (fsToggle == 1) {
            fsToggle = 0
            fsPrev = fp
            takeSnapshot(f, vr, ov, now + 8000)
            return
        }
        val prev = fsPrev
        fsPrev = fp
        if (prev != null && diffRatio(fp, prev) < 0.04f) fsStable++ else fsStable = 0
        if (fsStable >= 2) {
            fsStable = 0
            takeSnapshot(f, vr, ov, 0L)
        }
    }

    private fun takeSnapshot(f: Bitmap, vr: Rect, ov: OverlayManager, holdUntil: Long) {
        val cx = vr.left.coerceIn(0, capW - 1)
        val cy = vr.top.coerceIn(0, capH - 1)
        val cw = minOf(vr.width(), capW - cx)
        val ch = minOf(vr.height(), capH - cy)
        if (cw < 64 || ch < 64) return
        val crop = Bitmap.createBitmap(f, cx, cy, cw, ch)
        val res = Tasks.await(recognizer!!.process(InputImage.fromBitmap(crop, 0)))
        crop.recycle()

        // the places already handled live are left to them
        val skip = ArrayList<Rect>()
        for (a in areas) {
            if (!prefs.areaOn(a.id)) continue
            val l = (vr.left + a.x * vr.width()).toInt()
            val t = (vr.top + a.y * vr.height()).toInt()
            skip.add(Rect(l, t, l + (a.w * vr.width()).toInt(), t + (a.h * vr.height()).toInt()))
        }
        val all = ArrayList<FsBlock>()
        for (b in res.textBlocks) {
            val r = b.boundingBox ?: continue
            val absR = Rect(r.left + cx, r.top + cy, r.right + cx, r.bottom + cy)
            val text = b.lines.joinToString(" ") { it.text }.replace(Regex("\\s+"), " ").trim()
            val norm = Txt.norm(text)
            if (norm.length < 3 || !Txt.latinOk(text)) continue
            if (r.height() < vr.height() * 0.012f) continue
            if (skip.any { Rect.intersects(it, absR) }) continue
            val lines = maxOf(1, b.lines.size)
            all.add(FsBlock(norm, text, absR, r.height().toFloat() / lines))
        }
        if (all.isEmpty()) return
        all.sortWith(compareBy<FsBlock>({ it.rect.top }, { it.rect.left }))
        val blocks = all.take(18)

        val gen = fsGen + 1
        fsGen = gen
        fsShown = true
        fsBase = null
        fsHoldUntil = holdUntil

        val renders = ArrayList<(String) -> Unit>()
        for ((i, b) in blocks.withIndex()) {
            val id = "f${gen}_$i"
            val size = (b.lineH * 0.85f * prefs.fontScale).coerceIn(vr.height() * 0.015f, vr.height() * 0.06f)
            val style = Style(prefs.fontColor, 0f, true, 0xF0)
            renders.add { ar ->
                if (fsGen == gen) {
                    ov.show(
                        id, ar, b.rect.left - 8, maxOf(60, b.rect.width() + 16), b.rect.top - 4, false,
                        maxOf(48, (b.rect.height() * 1.8f).toInt()), b.rect.height() + 8, size, false, style,
                    )
                }
            }
        }

        val useAi = prefs.engine == 1 && Ai.available(prefs) && blocks.any { aiCache[it.norm] == null }
        if (!useAi || !prefs.aiWait) {
            for ((i, b) in blocks.withIndex()) {
                val cached = aiCache[b.norm]
                renders[i](cached ?: offline(b.text))
            }
        }
        if (useAi) {
            val texts = blocks.map { it.text }
            aiPool.execute {
                val r: List<String?>? = try {
                    Ai.translateBatch(prefs, texts)
                } catch (e: Exception) {
                    Status.set("AI: ${e.message}")
                    null
                }
                for ((i, b) in blocks.withIndex()) {
                    val t = r?.get(i)
                    if (t != null) {
                        putAi(b.norm, t)
                        renders[i](t)
                    } else if (prefs.aiWait) {
                        val o = runCatching { offline(b.text) }.getOrNull()
                        if (o != null) renders[i](o)
                    }
                }
            }
        }
    }

    // ---------------------------------------------------------------- translation

    /** The offline translation, keeping the glossary words as they are (or as set). */
    private fun offline(text: String): String {
        val key = Txt.norm(text)
        offCache[key]?.let { return it }
        val gl = Glossary.parse(prefs.glossary)
        var t = text
        val hits = ArrayList<Pair<String, String>>()
        var n = 0
        for (g in gl) {
            val re = Regex(Regex.escape(g.src), RegexOption.IGNORE_CASE)
            if (re.containsMatchIn(t)) {
                val token = "Zq${n}x"
                t = re.replace(t, token)
                hits.add(token to (g.dst ?: g.src))
                n++
            }
        }
        var out = Tasks.await(translator!!.translate(t))
        if (hits.isNotEmpty()) {
            var ok = true
            for ((tok, rep) in hits) {
                if (out.contains(tok, ignoreCase = true)) out = out.replace(tok, rep, ignoreCase = true) else ok = false
            }
            // the model changed a placeholder: translate the plain text instead
            if (!ok) out = Tasks.await(translator!!.translate(text))
        }
        synchronized(offCache) {
            offCache[key] = out
            if (offCache.size > 500) {
                val iter = offCache.keys.iterator()
                iter.next()
                iter.remove()
            }
        }
        return out
    }

    private fun aiOrNull(key: String, text: String, ctxLines: List<String>): String? = try {
        val r = Ai.translate(prefs, text, ctxLines)
        putAi(key, r)
        r
    } catch (e: Exception) {
        Status.set("AI: ${e.message}")
        null
    }

    /**
     * Offline translation shows at once and the AI one replaces it when it arrives, or, with the
     * "wait" setting, nothing shows until the AI answers (the offline one if it fails).
     */
    private fun translateThen(key: String, text: String, ctxLines: List<String>, current: () -> Boolean, render: (String) -> Unit) {
        val cached = aiCache[key]
        if (cached != null) {
            render(cached)
            return
        }
        if (!(prefs.engine == 1 && Ai.available(prefs))) {
            render(offline(text))
            return
        }
        if (prefs.aiWait) {
            aiPool.execute {
                val r = aiOrNull(key, text, ctxLines)
                val result = r ?: runCatching { offline(text) }.getOrNull()
                if (result != null && current()) render(result)
            }
        } else {
            render(offline(text))
            aiPool.execute {
                val r = aiOrNull(key, text, ctxLines)
                if (r != null && current()) render(r)
            }
        }
    }

    private fun putAi(key: String, v: String) {
        synchronized(aiCache) {
            aiCache[key] = v
            if (aiCache.size > 1500) {
                val iter = aiCache.keys.iterator()
                iter.next()
                iter.remove()
            }
        }
        cacheDirty++
        if (cacheDirty >= 15) {
            cacheDirty = 0
            aiPool.execute { saveCacheNow() }
        }
    }

    private fun loadCache() {
        try {
            val file = File(filesDir, "ai_cache.json")
            if (!file.exists()) return
            val j = JSONObject(file.readText())
            val keys = j.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                aiCache[k] = j.getString(k)
            }
        } catch (ignored: Exception) {
        }
    }

    private fun saveCacheNow() {
        try {
            val j = JSONObject()
            synchronized(aiCache) {
                for ((k, v) in aiCache) j.put(k, v)
            }
            File(filesDir, "ai_cache.json").writeText(j.toString())
        } catch (ignored: Exception) {
        }
    }

    // ---------------------------------------------------------------- helpers

    private fun boostBitmap(src: Bitmap, k: Float): Bitmap {
        val out = Bitmap.createBitmap((src.width * k).toInt(), (src.height * k).toInt(), Bitmap.Config.ARGB_8888)
        Canvas(out).drawBitmap(src, Rect(0, 0, src.width, src.height), Rect(0, 0, out.width, out.height), boostPaint)
        return out
    }

    /** A rough fingerprint of the picture, to skip reading a place that didn't change. */
    private fun quickHash(b: Bitmap): Int {
        val s = Bitmap.createScaledBitmap(b, 32, 8, true)
        s.getPixels(hs, 0, 32, 0, 0, 32, 8)
        if (s !== b) s.recycle()
        var x = 17
        for (p in hs) x = x * 31 + ((p ushr 5) and 0x070707)
        return x
    }

    override fun onDestroy() {
        alive = false
        h?.removeCallbacksAndMessages(null)
        editor?.dismiss()
        control?.hide()
        awake?.off()
        overlay?.clearAll()
        saveCacheNow()
        aiPool.shutdownNow()
        try {
            vd?.release()
        } catch (ignored: Exception) {
        }
        try {
            reader?.close()
        } catch (ignored: Exception) {
        }
        try {
            projection?.unregisterCallback(projectionCallback)
            projection?.stop()
        } catch (ignored: Exception) {
        }
        try {
            recognizer?.close()
            translator?.close()
        } catch (ignored: Exception) {
        }
        worker?.quitSafely()
        Status.markRunning(false)
        Status.set("متوقف")
        super.onDestroy()
    }

    companion object {
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        const val ACTION_STOP = "app.gtasubs.STOP"
        const val ACTION_EDIT = "app.gtasubs.EDIT"
        private const val CHANNEL = "cap"
    }
}
