package app.gtasubs

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs

/** A small round button over the game: tap it for a menu, drag it to move it. */
class FloatingControl(
    ctx: Context,
    private val onToggle: () -> Unit,
    private val onSnapshot: () -> Unit,
    private val onEdit: () -> Unit,
    private val onOpen: () -> Unit,
) {
    private val ctx = ctx.applicationContext
    private val wm = this.ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val main = Handler(Looper.getMainLooper())
    private var root: LinearLayout? = null
    private var toggleItem: TextView? = null
    private var paused = false
    private var lastX = 24
    private var lastY = 200

    fun show() {
        main.post { if (root == null) build() }
    }

    fun hide() {
        main.post {
            val r = root
            if (r != null) {
                try {
                    wm.removeView(r)
                } catch (ignored: Exception) {
                }
                root = null
            }
        }
    }

    fun setPaused(p: Boolean) {
        paused = p
        main.post { toggleItem?.text = label() }
    }

    private fun label(): String = if (paused) "▶  شغّل الترجمة" else "⏸  وقّف الترجمة"

    private fun build() {
        val density = ctx.resources.displayMetrics.density
        fun d(v: Int): Int = (v * density).toInt()

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = lastX
        lp.y = lastY

        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        val menu = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(d(6), d(6), d(6), d(6))
            background = GradientDrawable().apply {
                setColor(0xEE222222.toInt())
                cornerRadius = d(12).toFloat()
            }
        }

        fun item(t: String, action: () -> Unit): TextView = TextView(ctx).apply {
            text = t
            textSize = 16f
            setTextColor(Color.WHITE)
            setPadding(d(12), d(10), d(12), d(10))
            setOnClickListener {
                menu.visibility = View.GONE
                action()
            }
        }

        val tItem = item(label(), onToggle)
        toggleItem = tItem
        menu.addView(tItem)
        menu.addView(item("🖼  ترجم الشاشة كلها", onSnapshot))
        menu.addView(item("📐  ضبط الأماكن", onEdit))
        menu.addView(item("⚙  فتح التطبيق", onOpen))

        val fab = TextView(ctx).apply {
            text = "ع"
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xCCE91E63.toInt())
            }
            layoutParams = LinearLayout.LayoutParams(d(48), d(48))
        }

        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moved = false
        fab.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    startX = lp.x
                    startY = lp.y
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (moved || abs(dx) > 12 || abs(dy) > 12) {
                        moved = true
                        lp.x = startX + dx.toInt()
                        lp.y = startY + dy.toInt()
                        lastX = lp.x
                        lastY = lp.y
                        try {
                            wm.updateViewLayout(col, lp)
                        } catch (ignored: Exception) {
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        menu.visibility = if (menu.visibility == View.VISIBLE) View.GONE else View.VISIBLE
                    }
                    true
                }
                else -> false
            }
        }

        col.addView(fab)
        col.addView(menu)
        try {
            wm.addView(col, lp)
            root = col
        } catch (e: Exception) {
            Status.set("مش قادر أعرض الزرار العائم: ${e.message}")
        }
    }
}

/** A 1-pixel invisible window whose only job is keeping the tablet's screen on. */
class AwakeWindow(ctx: Context) {
    private val ctx = ctx.applicationContext
    private val wm = this.ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val main = Handler(Looper.getMainLooper())
    private var v: View? = null

    fun on() {
        main.post {
            if (v == null) {
                try {
                    val view = View(ctx)
                    val lp = WindowManager.LayoutParams(
                        1, 1,
                        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                        PixelFormat.TRANSLUCENT,
                    )
                    lp.gravity = Gravity.TOP or Gravity.START
                    wm.addView(view, lp)
                    v = view
                } catch (ignored: Exception) {
                }
            }
        }
    }

    fun off() {
        main.post {
            val view = v
            if (view != null) {
                try {
                    wm.removeView(view)
                } catch (ignored: Exception) {
                }
                v = null
            }
        }
    }
}
