package app.gtasubs

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.hypot

/**
 * Draws over the game picture so you can move and resize the places by dragging:
 * blue = where the English is read, green = where the Arabic goes, red = the game picture itself.
 */
class Editor(
    ctx: Context,
    private val prefs: Prefs,
    private val sw: Int,
    private val sh: Int,
    private val onClose: () -> Unit,
) {
    private val ctx = ctx.applicationContext
    private val wm = this.ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val main = Handler(Looper.getMainLooper())
    private val density = this.ctx.resources.displayMetrics.density

    private val areas = ArrayList<AreaDef>()
    private val reads = ArrayList<RectF>()
    private val outs = ArrayList<RectF>()
    private val places = ArrayList<Int>()
    private var videoR = RectF()
    private var videoEdited = false
    private var sel = 0

    private var root: FrameLayout? = null
    private var view: EditView? = null
    private var nameLabel: TextView? = null
    private var placeBtn: Button? = null
    private var delBtn: Button? = null

    init {
        val vr = Geo.video(sw, sh, prefs)
        videoR = RectF(vr)
        val vw = vr.width().toFloat()
        val vh = vr.height().toFloat()
        for (a in Areas.load(prefs)) {
            areas.add(a)
            reads.add(RectF(vr.left + a.x * vw, vr.top + a.y * vh, vr.left + (a.x + a.w) * vw, vr.top + (a.y + a.h) * vh))
            outs.add(
                RectF(
                    vr.left + a.outX * vw, vr.top + a.outY * vh,
                    vr.left + (a.outX + a.outW) * vw, vr.top + (a.outY + a.outH) * vh,
                ),
            )
            places.add(a.placement)
        }
    }

    private fun d(v: Int): Int = (v * density).toInt()

    fun show() {
        main.post {
            if (root != null) return@post
            val fl = FrameLayout(ctx)
            val v = EditView(ctx)
            view = v
            fl.addView(v, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

            fun btn(t: String, onClick: () -> Unit): Button = Button(ctx).apply {
                text = t
                textSize = 14f
                isAllCaps = false
                setOnClickListener { onClick() }
            }

            val bar = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setBackgroundColor(0xE6202020.toInt())
                setPadding(d(8), d(4), d(8), d(4))
                layoutDirection = View.LAYOUT_DIRECTION_RTL
            }
            val label = TextView(ctx).apply {
                textSize = 15f
                setTextColor(Color.WHITE)
                setPadding(d(10), 0, d(10), 0)
            }
            nameLabel = label
            val pb = btn("") { cyclePlacement() }
            placeBtn = pb
            val db = btn("🗑 حذف") { deleteSelected() }
            delBtn = db
            bar.addView(btn("▶") { select((sel + 1) % (areas.size + 1)) })
            bar.addView(label)
            bar.addView(btn("◀") { select((sel - 1 + areas.size + 1) % (areas.size + 1)) })
            bar.addView(pb)
            bar.addView(btn("＋ مكان جديد") { addArea() })
            bar.addView(db)
            bar.addView(btn("✔ حفظ") { save() })
            bar.addView(btn("✖ إلغاء") { close() })
            fl.addView(bar, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.CENTER_HORIZONTAL))

            val hint = TextView(ctx).apply {
                text = "اسحب المستطيل لتحريكه، واسحب الدواير اللي في الأركان لتكبيره أو تصغيره.\n" +
                    "الأزرق = مكان قراءة الإنجليزي  |  الأخضر = مكان العربي  |  الأحمر = حدود صورة اللعبة"
                textSize = 14f
                setTextColor(Color.WHITE)
                setBackgroundColor(0xCC202020.toInt())
                setPadding(d(12), d(6), d(12), d(6))
                gravity = Gravity.CENTER
                layoutDirection = View.LAYOUT_DIRECTION_RTL
            }
            fl.addView(hint, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL))

            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT,
            )
            if (Build.VERSION.SDK_INT >= 30) {
                lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            }
            try {
                wm.addView(fl, lp)
                root = fl
                refreshUi()
            } catch (e: Exception) {
                Status.set("مش قادر أفتح ضبط الأماكن: ${e.message}")
                onClose()
            }
        }
    }

    /** Closes the editor without saving (also used when the service stops). */
    fun dismiss() {
        main.post { removeRoot() }
    }

    private fun removeRoot() {
        val r = root ?: return
        try {
            wm.removeView(r)
        } catch (ignored: Exception) {
        }
        root = null
    }

    private fun close() {
        removeRoot()
        onClose()
    }

    private fun save() {
        val vw = maxOf(1f, videoR.width())
        val vh = maxOf(1f, videoR.height())
        val out = ArrayList<AreaDef>()
        for (i in areas.indices) {
            val r = reads[i]
            val o = outs[i]
            out.add(
                areas[i].copy(
                    x = (r.left - videoR.left) / vw, y = (r.top - videoR.top) / vh,
                    w = r.width() / vw, h = r.height() / vh,
                    outX = (o.left - videoR.left) / vw, outY = (o.top - videoR.top) / vh,
                    outW = o.width() / vw, outH = o.height() / vh,
                    placement = places[i],
                ),
            )
        }
        Areas.save(prefs, out)
        if (videoEdited) {
            prefs.videoRect = floatArrayOf(videoR.left / sw, videoR.top / sh, videoR.right / sw, videoR.bottom / sh)
            prefs.aspect = 2
        }
        close()
    }

    private fun select(i: Int) {
        sel = i
        refreshUi()
    }

    private fun refreshUi() {
        val isVideo = sel >= areas.size
        nameLabel?.text = if (isVideo) "الصورة (حدود الفيديو)" else areas[sel].label
        placeBtn?.visibility = if (isVideo) View.GONE else View.VISIBLE
        delBtn?.visibility = if (isVideo) View.GONE else View.VISIBLE
        if (!isVideo) {
            placeBtn?.text = when (places[sel]) {
                0 -> "العربي: مكان ثابت (الأخضر)"
                1 -> "العربي: تحت الإنجليزي"
                else -> "العربي: فوق الإنجليزي"
            }
        }
        view?.invalidate()
    }

    private fun cyclePlacement() {
        if (sel >= areas.size) return
        places[sel] = (places[sel] + 1) % 3
        if (places[sel] == 0) {
            val o = outs[sel]
            val r = reads[sel]
            if (o.width() < 40f || o.height() < 40f) {
                outs[sel] = RectF(r.left, r.bottom + 10f, r.right, r.bottom + 10f + maxOf(60f, r.height()))
            }
        }
        refreshUi()
    }

    private fun addArea() {
        val n = areas.size + 1
        val vw = videoR.width()
        val vh = videoR.height()
        areas.add(
            AreaDef(
                "u" + System.currentTimeMillis(), "مكان جديد $n",
                0.3f, 0.45f, 0.4f, 0.1f,
                0.3f, 0.58f, 0.4f, 0.1f,
                placement = 1, centeredOnly = false, darkBox = true, sizeScale = 1f,
            ),
        )
        reads.add(RectF(videoR.left + 0.3f * vw, videoR.top + 0.45f * vh, videoR.left + 0.7f * vw, videoR.top + 0.55f * vh))
        outs.add(RectF(videoR.left + 0.3f * vw, videoR.top + 0.58f * vh, videoR.left + 0.7f * vw, videoR.top + 0.68f * vh))
        places.add(1)
        select(areas.size - 1)
    }

    private fun deleteSelected() {
        if (sel >= areas.size) return
        areas.removeAt(sel)
        reads.removeAt(sel)
        outs.removeAt(sel)
        places.removeAt(sel)
        select(sel.coerceAtMost(areas.size))
    }

    private fun rectsFor(i: Int): List<RectF> = when {
        i >= areas.size -> listOf(videoR)
        places[i] == 0 -> listOf(outs[i], reads[i])
        else -> listOf(reads[i])
    }

    private inner class EditView(c: Context) : View(c) {
        private val cRead = 0xFF40C4FF.toInt()
        private val cOut = 0xFF69F0AE.toInt()
        private val cVideo = 0xFFFF5252.toInt()
        private val strokeP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
        private val fillP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        private val textP = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 30f }

        private var drag: RectF? = null
        private var mode = 0 // 0 nothing, 1 move, 2 resize
        private var corner = 0
        private var lastX = 0f
        private var lastY = 0f

        private fun label(c: Canvas, t: String, r: RectF, color: Int) {
            textP.color = color
            c.drawText(t, r.left + 8f, if (r.top < 40f) r.top + 34f else r.top - 8f, textP)
        }

        private fun box(c: Canvas, r: RectF, color: Int, thick: Boolean, text: String) {
            fillP.color = (0x30 shl 24) or (color and 0xFFFFFF)
            c.drawRect(r, fillP)
            strokeP.color = color
            strokeP.strokeWidth = if (thick) 6f else 3f
            c.drawRect(r, strokeP)
            label(c, text, r, color)
        }

        override fun onDraw(c: Canvas) {
            c.drawColor(0x55000000)
            box(c, videoR, cVideo, sel >= areas.size, "الصورة")
            for (i in areas.indices) {
                val on = i == sel
                box(c, reads[i], cRead, on, areas[i].label + " (قراءة)")
                if (places[i] == 0) box(c, outs[i], cOut, on, areas[i].label + " (العربي)")
            }
            val color = if (sel >= areas.size) cVideo else cRead
            for (r in rectsFor(sel)) {
                val col = if (r === videoR) cVideo else if (sel < areas.size && r === outs[sel]) cOut else color
                for (p in corners(r)) {
                    fillP.color = Color.WHITE
                    c.drawCircle(p[0], p[1], 18f, fillP)
                    strokeP.color = col
                    strokeP.strokeWidth = 5f
                    c.drawCircle(p[0], p[1], 18f, strokeP)
                }
            }
        }

        private fun corners(r: RectF): List<FloatArray> = listOf(
            floatArrayOf(r.left, r.top), floatArrayOf(r.right, r.top),
            floatArrayOf(r.left, r.bottom), floatArrayOf(r.right, r.bottom),
        )

        private fun cornerAt(r: RectF, x: Float, y: Float): Int {
            var best = -1
            var bestD = 56f
            for ((i, p) in corners(r).withIndex()) {
                val dist = hypot(x - p[0], y - p[1])
                if (dist < bestD) {
                    bestD = dist
                    best = i
                }
            }
            return best
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    val x = e.x
                    val y = e.y
                    lastX = x
                    lastY = y
                    mode = 0
                    drag = null
                    for (r in rectsFor(sel)) {
                        val cn = cornerAt(r, x, y)
                        if (cn >= 0) {
                            drag = r
                            mode = 2
                            corner = cn
                            return true
                        }
                    }
                    for (r in rectsFor(sel)) {
                        if (r.contains(x, y)) {
                            drag = r
                            mode = 1
                            return true
                        }
                    }
                    for (i in areas.size downTo 0) {
                        if (i == sel) continue
                        if (rectsFor(i).any { it.contains(x, y) }) {
                            select(i)
                            return true
                        }
                    }
                }
                MotionEvent.ACTION_MOVE -> {
                    val r = drag ?: return true
                    val dx = e.x - lastX
                    val dy = e.y - lastY
                    lastX = e.x
                    lastY = e.y
                    if (mode == 1) {
                        r.offset(dx, dy)
                        if (r.left < 0f) r.offset(-r.left, 0f)
                        if (r.top < 0f) r.offset(0f, -r.top)
                        if (r.right > sw) r.offset(sw - r.right, 0f)
                        if (r.bottom > sh) r.offset(0f, sh - r.bottom)
                    } else if (mode == 2) {
                        when (corner) {
                            0 -> { r.left += dx; r.top += dy }
                            1 -> { r.right += dx; r.top += dy }
                            2 -> { r.left += dx; r.bottom += dy }
                            else -> { r.right += dx; r.bottom += dy }
                        }
                        if (r.right - r.left < 40f) {
                            if (corner == 0 || corner == 2) r.left = r.right - 40f else r.right = r.left + 40f
                        }
                        if (r.bottom - r.top < 40f) {
                            if (corner == 0 || corner == 1) r.top = r.bottom - 40f else r.bottom = r.top + 40f
                        }
                        r.left = r.left.coerceAtLeast(0f)
                        r.top = r.top.coerceAtLeast(0f)
                        r.right = r.right.coerceAtMost(sw.toFloat())
                        r.bottom = r.bottom.coerceAtMost(sh.toFloat())
                    }
                    if (r === videoR) videoEdited = true
                    invalidate()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    drag = null
                    mode = 0
                }
            }
            return true
        }
    }
}
