package app.gtasubs

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionConfig
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var prefs: Prefs
    private lateinit var status: TextView
    private lateinit var startBtn: Button
    private lateinit var aspectBtn: Button
    private val main = Handler(Looper.getMainLooper())
    private var test: OverlayManager? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        buildUi()
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
        }
    }

    override fun onResume() {
        super.onResume()
        Status.listener = { refresh() }
        refresh()
    }

    override fun onPause() {
        Status.listener = null
        super.onPause()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildUi() {
        val pad = dp(20)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        fun tv(t: String, size: Float = 16f) = TextView(this).apply {
            text = t
            textSize = size
            setPadding(0, dp(8), 0, dp(4))
        }

        col.addView(tv("مترجم GTA: ترجمة فورية على التابلت", 22f))
        status = tv("", 15f)
        col.addView(status)

        startBtn = Button(this).apply { setOnClickListener { onStartStop() } }
        col.addView(startBtn)
        col.addView(Button(this).apply {
            text = "تجربة مكان الترجمة (٥ ثواني)"
            setOnClickListener { sample() }
        })

        val fsLabel = tv("", 15f)
        fun fsText() {
            fsLabel.text = "حجم الخط: ${(prefs.fontScale * 100).toInt()}%"
        }
        fsText()
        col.addView(fsLabel)
        col.addView(SeekBar(this).apply {
            max = 100
            progress = ((prefs.fontScale - 0.6f) / 1.2f * 100).toInt().coerceIn(0, 100)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) {
                        prefs.fontScale = 0.6f + p / 100f * 1.2f
                        fsText()
                    }
                }

                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })

        aspectBtn = Button(this).apply {
            setOnClickListener {
                prefs.aspect = 1 - prefs.aspect
                aspectText()
            }
        }
        aspectText()
        col.addView(aspectBtn)

        col.addView(tv("الأماكن اللي بيقراها:"))
        for (a in Areas.all) {
            col.addView(CheckBox(this).apply {
                text = a.label
                isChecked = prefs.areaOn(a.id)
                setOnCheckedChangeListener { _, c -> prefs.setAreaOn(a.id, c) }
            })
        }

        col.addView(
            tv(
                "الخطوات:\n" +
                    "١) اضغط «ابدأ الترجمة» واسمح بالظهور فوق التطبيقات وتصوير الشاشة (اختار الشاشة كلها).\n" +
                    "٢) افتح USB Camera Pro وشغّل صورة الكابشر كارد ملء الشاشة.\n" +
                    "٣) أول مرة محتاج إنترنت لتحميل نموذج الترجمة.\n" +
                    "لو الكلام مش في مكانه جرّب «شكل الصورة» وزرار التجربة.",
                14f,
            ),
        )

        setContentView(ScrollView(this).apply {
            fitsSystemWindows = true
            addView(col)
        })
    }

    private fun aspectText() {
        aspectBtn.text = if (prefs.aspect == 0) {
            "شكل الصورة: 16:9 (فيه شرايط سودا فوق وتحت)"
        } else {
            "شكل الصورة: ملء الشاشة"
        }
    }

    private fun refresh() {
        status.text = Status.line + if (Status.last.isNotEmpty()) "\n" + Status.last else ""
        startBtn.text = if (Status.running) "إيقاف الترجمة" else "ابدأ الترجمة"
    }

    private fun needOverlayPermission(): Boolean {
        if (Settings.canDrawOverlays(this)) return false
        Toast.makeText(this, "فعّل «العرض فوق التطبيقات الأخرى» ثم ارجع", Toast.LENGTH_LONG).show()
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        return true
    }

    private fun onStartStop() {
        if (Status.running) {
            stopService(Intent(this, CaptureService::class.java))
            return
        }
        if (needOverlayPermission()) return
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val intent = if (Build.VERSION.SDK_INT >= 34) {
            // the whole screen, not "one app" (the game picture is in another app)
            mpm.createScreenCaptureIntent(MediaProjectionConfig.createConfigForDefaultDisplay())
        } else {
            mpm.createScreenCaptureIntent()
        }
        @Suppress("DEPRECATION")
        startActivityForResult(intent, REQ_CAPTURE)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_CAPTURE) return
        if (resultCode == RESULT_OK && data != null) {
            val i = Intent(this, CaptureService::class.java)
                .putExtra(CaptureService.EXTRA_CODE, resultCode)
                .putExtra(CaptureService.EXTRA_DATA, data)
            startForegroundService(i)
            Toast.makeText(this, "تمام، افتح USB Camera Pro", Toast.LENGTH_LONG).show()
            moveTaskToBack(true)
        } else {
            Status.set("اتلغى طلب تصوير الشاشة")
        }
    }

    /** Shows a sample Arabic line in the subtitles' place, to check where it lands. */
    private fun sample() {
        if (needOverlayPermission()) return
        val om = test ?: OverlayManager(applicationContext).also { test = it }
        val (w, h) = Geo.screen(this)
        val vr = Geo.video(w, h, prefs.aspect)
        val a = Areas.all[0]
        val size = (vr.height() * 0.035f * prefs.fontScale)
        om.showFixed(a, vr, "ده مثال للترجمة العربية في مكانها على الصورة", size)
        main.postDelayed({ om.clearAll() }, 5000)
        Toast.makeText(this, "افتح USB Camera Pro بسرعة وشوف المكان", Toast.LENGTH_SHORT).show()
    }

    companion object {
        private const val REQ_CAPTURE = 1
    }
}
