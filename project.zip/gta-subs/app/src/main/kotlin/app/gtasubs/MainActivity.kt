package app.gtasubs

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionConfig
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var prefs: Prefs
    private lateinit var status: TextView
    private lateinit var startBtn: Button
    private lateinit var aspectBtn: Button
    private lateinit var areaBox: LinearLayout
    private val main = Handler(Looper.getMainLooper())
    private var test: OverlayManager? = null
    private val swatches = ArrayList<Pair<View, Int>>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        buildUi()
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
        }
    }

    override fun onResume() {
        super.onResume()
        Status.listener = { refresh() }
        refresh()
        fillAreas()
    }

    override fun onPause() {
        Status.listener = null
        super.onPause()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun toast(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    }

    private fun tv(t: String, size: Float = 16f): TextView = TextView(this).apply {
        text = t
        textSize = size
        setPadding(0, dp(8), 0, dp(4))
    }

    private fun section(col: LinearLayout, title: String) {
        col.addView(tv(title, 20f).apply {
            setPadding(0, dp(22), 0, dp(6))
            setTextColor(0xFFFF80AB.toInt())
        })
    }

    private fun choice(col: LinearLayout, title: String, options: List<String>, get: () -> Int, set: (Int) -> Unit) {
        col.addView(tv(title))
        val g = RadioGroup(this)
        g.orientation = RadioGroup.VERTICAL
        val ids = ArrayList<Int>()
        for (t in options) {
            val rb = RadioButton(this)
            rb.id = View.generateViewId()
            rb.text = t
            ids.add(rb.id)
            g.addView(rb)
        }
        g.check(ids[get().coerceIn(0, ids.size - 1)])
        g.setOnCheckedChangeListener { _, id ->
            val i = ids.indexOf(id)
            if (i >= 0) set(i)
        }
        col.addView(g)
    }

    private fun checkbox(col: LinearLayout, text: String, get: () -> Boolean, set: (Boolean) -> Unit) {
        val cb = CheckBox(this)
        cb.text = text
        cb.isChecked = get()
        cb.setOnCheckedChangeListener { _, c -> set(c) }
        col.addView(cb)
    }

    private fun field(col: LinearLayout, hint: String, value: String, secret: Boolean, onChange: (String) -> Unit) {
        val et = EditText(this)
        et.hint = hint
        et.setText(value)
        et.setSingleLine(true)
        if (secret) et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        et.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                onChange(s?.toString() ?: "")
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
        col.addView(et)
    }

    private fun button(col: LinearLayout, text: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.setOnClickListener { onClick() }
        col.addView(b)
        return b
    }

    private fun buildUi() {
        val pad = dp(20)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(pad, pad, pad, pad)
        col.layoutDirection = View.LAYOUT_DIRECTION_RTL

        col.addView(tv("مترجم GTA: ترجمة فورية على التابلت", 22f))
        status = tv("", 15f)
        col.addView(status)

        startBtn = button(col, "") { onStartStop() }
        button(col, "تجربة مكان الترجمة (٥ ثواني)") { sample() }
        button(col, "📐 ضبط الأماكن بالسحب") { editAreas() }

        // ---- translation
        section(col, "الترجمة")
        choice(
            col, "طريقة الترجمة",
            listOf("أوفلاين بس (سريعة، من غير نت)", "ذكاء اصطناعي Gemini (أدق) وبيرجع للأوفلاين لو النت وقع"),
            { prefs.engine }, { prefs.engine = it },
        )
        choice(
            col, "مع الذكاء الاصطناعي",
            listOf("اعرض الأوفلاين فوراً وبدّله بالأدق لما يوصل", "استنى الترجمة الدقيقة وبعدين اعرض (تأخير أكبر)"),
            { if (prefs.aiWait) 1 else 0 }, { prefs.aiWait = it == 1 },
        )
        choice(
            col, "أسلوب الترجمة بالذكاء الاصطناعي",
            listOf("عربي فصيح مبسط", "عامية مصرية"),
            { prefs.dialect }, { prefs.dialect = it },
        )
        col.addView(tv("مفتاح Gemini (من aistudio.google.com ثم Get API key). الحد المجاني حوالي ١٠ إلى ١٥ طلب في الدقيقة.", 14f))
        field(col, "مفتاح الـAPI", prefs.apiKey, true) { prefs.apiKey = it.trim() }
        field(col, "اسم الموديل", prefs.model, false) { prefs.model = it.trim() }
        button(col, "اختبار مفتاح الـAPI") { testAi() }
        button(col, "📖 قاموس المصطلحات (أسماء تفضل زي ما هي)") { glossary() }
        checkbox(col, "الوضع السريع (يعرض من أول قراءة ويفحص الشاشة أسرع)", { prefs.fast }, { prefs.fast = it })

        // ---- scope
        section(col, "إيه اللي يتترجم")
        choice(
            col, "نطاق الترجمة",
            listOf(
                "الأماكن اللي حددتها بس (الحوار والتعليمات)",
                "الأماكن + الشاشة كلها لما الصورة تثبت (قوائم، خريطة، إيقاف)",
            ),
            { prefs.scope }, { prefs.scope = it },
        )
        col.addView(tv("الزرار العائم فيه «ترجم الشاشة كلها» لو عاوزها في أي وقت لمدة ٨ ثواني.", 14f))

        // ---- looks
        section(col, "الشكل")
        col.addView(tv("لون الخط"))
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val colors = listOf(0xFFFFFFFFL, 0xFFFFEB3BL, 0xFF80D8FFL, 0xFF69F0AEL, 0xFFFFAB40L, 0xFFFF80ABL, 0xFFB388FFL, 0xFFBDBDBDL)
        for (cl in colors) {
            val c = cl.toInt()
            val sw = View(this)
            val lp = LinearLayout.LayoutParams(dp(40), dp(40))
            lp.setMargins(dp(4), dp(4), dp(4), dp(4))
            sw.layoutParams = lp
            sw.setOnClickListener {
                prefs.fontColor = c
                paintSwatches()
            }
            swatches.add(sw to c)
            row.addView(sw)
        }
        col.addView(row)
        paintSwatches()

        val strokeLabel = tv("", 15f)
        fun strokeText() {
            strokeLabel.text = "سُمك الحدّ الأسود: ${(prefs.strokeScale * 100).toInt()}%"
        }
        strokeText()
        col.addView(strokeLabel)
        val sb2 = SeekBar(this)
        sb2.max = 100
        sb2.progress = (prefs.strokeScale / 2.5f * 100).toInt().coerceIn(0, 100)
        sb2.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) {
                    prefs.strokeScale = p / 100f * 2.5f
                    strokeText()
                }
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        col.addView(sb2)

        val fsLabel = tv("", 15f)
        fun fsText() {
            fsLabel.text = "حجم الخط: ${(prefs.fontScale * 100).toInt()}%"
        }
        fsText()
        col.addView(fsLabel)
        val sb = SeekBar(this)
        sb.max = 100
        sb.progress = ((prefs.fontScale - 0.6f) / 1.2f * 100).toInt().coerceIn(0, 100)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) {
                    prefs.fontScale = 0.6f + p / 100f * 1.2f
                    fsText()
                }
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        col.addView(sb)

        checkbox(col, "خلفية غامقة شفافة ورا الترجمة", { prefs.textBg }, { prefs.textBg = it })

        aspectBtn = button(col, "") {
            prefs.aspect = (prefs.aspect + 1) % 3
            aspectText()
        }
        aspectText()

        // ---- places
        section(col, "الأماكن اللي بيقراها")
        areaBox = LinearLayout(this)
        areaBox.orientation = LinearLayout.VERTICAL
        col.addView(areaBox)
        button(col, "رجّع الأماكن للوضع الافتراضي") {
            Areas.reset(prefs)
            fillAreas()
            toast("اتّرجعت الأماكن الافتراضية")
        }

        // ---- other
        section(col, "أخرى")
        checkbox(col, "الزرار العائم فوق اللعبة", { prefs.floatBtn }, { prefs.floatBtn = it })
        checkbox(col, "خلّي الشاشة منوّرة وهو شغال", { prefs.keepOn }, { prefs.keepOn = it })
        checkbox(col, "تحسين قراءة الكلام الصغير (أبطأ شوية)", { prefs.boost }, { prefs.boost = it })

        col.addView(
            tv(
                "الخطوات:\n" +
                    "١) اضغط «ابدأ الترجمة» واسمح بالظهور فوق التطبيقات وتصوير الشاشة (اختار الشاشة كلها).\n" +
                    "٢) افتح USB Camera Pro وشغّل صورة الكابشر كارد ملء الشاشة.\n" +
                    "٣) أول مرة محتاج إنترنت لتحميل نموذج الترجمة.\n" +
                    "٤) لو الأماكن مش مظبوطة: الزرار العائم ثم «ضبط الأماكن».",
                14f,
            ),
        )

        val scroll = ScrollView(this)
        scroll.fitsSystemWindows = true
        scroll.addView(col)
        setContentView(scroll)
    }

    private fun paintSwatches() {
        for ((v, c) in swatches) {
            val sel = c == prefs.fontColor
            val g = GradientDrawable()
            g.shape = GradientDrawable.OVAL
            g.setColor(c)
            g.setStroke(dp(if (sel) 4 else 1), if (sel) 0xFFE91E63.toInt() else Color.GRAY)
            v.background = g
        }
    }

    private fun fillAreas() {
        areaBox.removeAllViews()
        for (a in Areas.load(prefs)) {
            val cb = CheckBox(this)
            cb.text = a.label
            cb.isChecked = prefs.areaOn(a.id)
            cb.setOnCheckedChangeListener { _, c -> prefs.setAreaOn(a.id, c) }
            areaBox.addView(cb)
        }
    }

    private fun aspectText() {
        aspectBtn.text = when (prefs.aspect) {
            0 -> "شكل الصورة: 16:9 (فيه شرايط سودا فوق وتحت)"
            1 -> "شكل الصورة: ملء الشاشة"
            else -> "شكل الصورة: مخصص (اللي ضبطته في ضبط الأماكن)"
        }
    }

    private fun refresh() {
        status.text = Status.line + if (Status.last.isNotEmpty()) "\n" + Status.last else ""
        startBtn.text = if (Status.running) "إيقاف الترجمة" else "ابدأ الترجمة"
    }

    private fun needOverlayPermission(): Boolean {
        if (Settings.canDrawOverlays(this)) return false
        toast("فعّل «العرض فوق التطبيقات الأخرى» ثم ارجع")
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        return true
    }

    private fun onStartStop() {
        if (Status.running) {
            stopService(Intent(this, CaptureService::class.java))
            return
        }
        if (needOverlayPermission()) return
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val intent = if (Build.VERSION.SDK_INT >= 34) {
            // the whole screen, not "one app" (the game picture is in another app)
            mpm.createScreenCaptureIntent(MediaProjectionConfig.createConfigForDefaultDisplay())
        } else {
            mpm.createScreenCaptureIntent()
        }
        @Suppress("DEPRECATION")
        startActivityForResult(intent, REQ_CAPTURE)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_CAPTURE) return
        if (resultCode == RESULT_OK && data != null) {
            val i = Intent(this, CaptureService::class.java)
                .putExtra(CaptureService.EXTRA_CODE, resultCode)
                .putExtra(CaptureService.EXTRA_DATA, data)
            startForegroundService(i)
            toast("تمام، افتح USB Camera Pro")
            moveTaskToBack(true)
        } else {
            Status.set("اتلغى طلب تصوير الشاشة")
        }
    }

    private fun editAreas() {
        if (!Status.running) {
            toast("ابدأ الترجمة الأول وافتح USB Camera Pro، وبعدين الزرار العائم ثم «ضبط الأماكن»")
            return
        }
        if (needOverlayPermission()) return
        startService(Intent(this, CaptureService::class.java).setAction(CaptureService.ACTION_EDIT))
        moveTaskToBack(true)
    }

    private fun testAi() {
        toast("بجرّب الاتصال…")
        Thread {
            val msg = try {
                "تمام: " + Ai.translate(prefs, "Paradise Taxi. How can we help you?", emptyList())
            } catch (e: Exception) {
                "فشل: ${e.message}"
            }
            runOnUiThread { toast(msg) }
        }.start()
    }

    private fun glossary() {
        val et = EditText(this)
        et.setText(prefs.glossary)
        et.minLines = 8
        et.gravity = Gravity.TOP or Gravity.START
        AlertDialog.Builder(this)
            .setTitle("قاموس المصطلحات")
            .setMessage("كل سطر: كلمة تفضل زي ما هي، أو «كلمة = ترجمتها»")
            .setView(et)
            .setPositiveButton("حفظ") { _, _ -> prefs.glossary = et.text.toString() }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    /** Shows a sample Arabic line in the subtitles' place, to check where it lands. */
    private fun sample() {
        if (needOverlayPermission()) return
        val om = test ?: OverlayManager(applicationContext).also { test = it }
        val (w, h) = Geo.screen(this)
        val vr = Geo.video(w, h, prefs)
        val a = Areas.load(prefs).firstOrNull { it.placement == 0 } ?: Areas.defaults()[0]
        val size = vr.height() * 0.035f * prefs.fontScale
        val st = Style(prefs.fontColor, prefs.strokeScale, prefs.textBg, 0x99)
        om.showFixed(a, vr, "ده مثال للترجمة العربية في مكانها على الصورة", size, st)
        main.postDelayed({ om.clearAll() }, 5000)
        toast("افتح USB Camera Pro بسرعة وشوف المكان")
    }

    companion object {
        private const val REQ_CAPTURE = 1
    }
}
