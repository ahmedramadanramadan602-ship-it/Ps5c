package app.gtasubs

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.Typeface
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import java.util.concurrent.ConcurrentHashMap

/** How the Arabic looks. boxAlpha is 0..255 (black box behind the text, used when box is true). */
class Style(val color: Int, val strokeScale: Float, val box: Boolean, val boxAlpha: Int)

/** The Arabic text: coloured with a black outline (or on a dark box), laid out right to left. */
class SubView(ctx: Context, private val face: Typeface) : View(ctx) {
    private var fill: StaticLayout? = null
    private var stroke: StaticLayout? = null
    private var pad = 0
    private var bg = 0
    private val bgPaint = Paint()

    /** The height this text needs, in pixels. */
    var contentHeight = 1
        private set

    fun setContent(
        text: String, widthPx: Int, sizePx: Float, maxHeightPx: Int, minHeightPx: Int,
        center: Boolean, st: Style,
    ) {
        pad = if (st.box) (sizePx * 0.35f).toInt() else 0
        bg = if (st.box) ((st.boxAlpha and 0xFF) shl 24) else 0
        bgPaint.color = bg
        val margin = 4
        val innerW = maxOf(40, widthPx - 2 * pad - 2 * margin)
        val useStroke = !st.box && st.strokeScale > 0f
        var size = sizePx
        var f: StaticLayout? = null
        var s: StaticLayout? = null
        while (true) {
            val fp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                typeface = face
                textSize = size
                color = st.color
            }
            f = build(text, fp, innerW, center)
            s = if (!useStroke) {
                null
            } else {
                val sp = TextPaint(fp).apply {
                    style = Paint.Style.STROKE
                    strokeWidth = maxOf(2f, size * 0.14f * st.strokeScale)
                    strokeJoin = Paint.Join.ROUND
                    color = Color.BLACK
                }
                build(text, sp, innerW, center)
            }
            if (f!!.height + 2 * pad + 2 * margin <= maxHeightPx || size <= sizePx * 0.5f) break
            size *= 0.92f
        }
        fill = f
        stroke = s
        contentHeight = maxOf(1, minHeightPx, f!!.height + 2 * pad + 2 * margin)
        invalidate()
    }

    private fun build(text: String, paint: TextPaint, width: Int, center: Boolean): StaticLayout =
        StaticLayout.Builder.obtain(text, 0, text.length, paint, width)
            .setAlignment(if (center) Layout.Alignment.ALIGN_CENTER else Layout.Alignment.ALIGN_NORMAL)
            .setTextDirection(TextDirectionHeuristics.RTL)
            .setIncludePad(false)
            .build()

    override fun onDraw(canvas: Canvas) {
        if (bg != 0) canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)
        val inner = (fill?.height ?: 0) + 2 * (pad + 4)
        val oy = ((height - inner) / 2).coerceAtLeast(0)
        canvas.save()
        canvas.translate((pad + 4).toFloat(), (pad + 4 + oy).toFloat())
        stroke?.draw(canvas)
        fill?.draw(canvas)
        canvas.restore()
    }
}

/** Small transparent windows over every other app, one per piece of text, sized to their text. */
class OverlayManager(ctx: Context) {
    private val ctx = ctx.applicationContext
    private val wm = this.ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val main = Handler(Looper.getMainLooper())
    private val face: Typeface = Typeface.createFromAsset(this.ctx.assets, "changa.ttf")

    private class Slot(val view: SubView, val lp: WindowManager.LayoutParams) {
        var attached = false
    }

    private val slots = HashMap<String, Slot>()
    private val rects = ConcurrentHashMap<String, Rect>()

    /** Where the windows are on the screen now (the capture paints them black before reading). */
    fun visibleRects(): List<Rect> = rects.values.toList()

    /** The Arabic of an area with a fixed rectangle (used by the test button). */
    fun showFixed(a: AreaDef, vr: Rect, text: String, sizePx: Float, st: Style) {
        val x = vr.left + (a.outX * vr.width()).toInt()
        val w = (a.outW * vr.width()).toInt()
        val bottom = vr.top + ((a.outY + a.outH) * vr.height()).toInt()
        show(a.id, text, x, w, bottom, true, maxOf(40, (a.outH * vr.height()).toInt()), 0, sizePx, true, st)
    }

    /**
     * anchorY is the window's top, or its bottom when bottom is true. minH keeps a box tall
     * enough to hide the English under it.
     */
    fun show(
        id: String, text: String, x: Int, w: Int, anchorY: Int, bottom: Boolean,
        maxH: Int, minH: Int, sizePx: Float, center: Boolean, st: Style,
    ) {
        main.post {
            try {
                val s = slots.getOrPut(id) { Slot(SubView(ctx, face), newParams()) }
                s.view.setContent(text, w, sizePx, maxH, minH, center, st)
                val h = s.view.contentHeight
                s.lp.width = w
                s.lp.height = h
                s.lp.x = x
                s.lp.y = if (bottom) anchorY - h else anchorY
                if (!s.attached) {
                    wm.addView(s.view, s.lp)
                    s.attached = true
                } else {
                    wm.updateViewLayout(s.view, s.lp)
                }
                rects[id] = Rect(s.lp.x, s.lp.y, s.lp.x + w, s.lp.y + h)
            } catch (e: Exception) {
                Status.set("مش قادر أرسم الترجمة: ${e.message}")
            }
        }
    }

    fun clear(id: String) {
        rects.remove(id)
        main.post { remove(id) }
    }

    fun clearPrefix(prefix: String) {
        rects.keys.filter { it.startsWith(prefix) }.forEach { rects.remove(it) }
        main.post { slots.keys.filter { it.startsWith(prefix) }.forEach { remove(it) } }
    }

    fun clearAll() {
        rects.clear()
        main.post { slots.keys.toList().forEach { remove(it) } }
    }

    private fun remove(id: String) {
        val s = slots.remove(id) ?: return
        if (s.attached) {
            try {
                wm.removeView(s.view)
            } catch (ignored: Exception) {
            }
        }
    }

    private fun newParams(): WindowManager.LayoutParams {
        val lp = WindowManager.LayoutParams(
            1, 1,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        )
        lp.gravity = Gravity.TOP or Gravity.START
        if (Build.VERSION.SDK_INT >= 30) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        }
        return lp
    }
}
