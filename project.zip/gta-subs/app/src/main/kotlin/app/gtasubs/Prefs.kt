package app.gtasubs

import android.content.Context
import android.graphics.Color
import android.os.Handler
import android.os.Looper

class Prefs(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("p", Context.MODE_PRIVATE)

    /** 0.6 .. 1.8 */
    var fontScale: Float
        get() = sp.getFloat("fs", 1.0f)
        set(v) = sp.edit().putFloat("fs", v).apply()

    /** 0: 16:9 with bars, 1: full screen, 2: custom rectangle (set in the area editor) */
    var aspect: Int
        get() = sp.getInt("aspect", 0)
        set(v) = sp.edit().putInt("aspect", v).apply()

    /** the custom picture rectangle as fractions of the screen: left, top, right, bottom */
    var videoRect: FloatArray?
        get() {
            val s = sp.getString("vr", null) ?: return null
            val p = s.split(",")
            if (p.size != 4) return null
            return try {
                FloatArray(4) { p[it].toFloat() }
            } catch (e: Exception) {
                null
            }
        }
        set(v) = sp.edit().putString("vr", v?.joinToString(",")).apply()

    fun areaOn(id: String): Boolean = sp.getBoolean("a_$id", true)
    fun setAreaOn(id: String, on: Boolean) = sp.edit().putBoolean("a_$id", on).apply()

    var fontColor: Int
        get() = sp.getInt("color", Color.WHITE)
        set(v) = sp.edit().putInt("color", v).apply()

    /** 0 (no outline) .. 2.5 */
    var strokeScale: Float
        get() = sp.getFloat("stroke", 1.0f)
        set(v) = sp.edit().putFloat("stroke", v).apply()

    var textBg: Boolean
        get() = sp.getBoolean("textbg", false)
        set(v) = sp.edit().putBoolean("textbg", v).apply()

    /** 0: offline only, 1: AI (Gemini) with the offline one as a fallback */
    var engine: Int
        get() = sp.getInt("engine", 0)
        set(v) = sp.edit().putInt("engine", v).apply()

    /** with AI: wait for the accurate translation before showing anything */
    var aiWait: Boolean
        get() = sp.getBoolean("aiwait", false)
        set(v) = sp.edit().putBoolean("aiwait", v).apply()

    /** 0: simple standard Arabic, 1: Egyptian */
    var dialect: Int
        get() = sp.getInt("dialect", 0)
        set(v) = sp.edit().putInt("dialect", v).apply()

    var apiKey: String
        get() = sp.getString("key", "") ?: ""
        set(v) = sp.edit().putString("key", v).apply()

    var model: String
        get() = sp.getString("model", "gemini-2.5-flash-lite") ?: "gemini-2.5-flash-lite"
        set(v) = sp.edit().putString("model", v).apply()

    var glossary: String
        get() = sp.getString("gloss", DEFAULT_GLOSSARY) ?: DEFAULT_GLOSSARY
        set(v) = sp.edit().putString("gloss", v).apply()

    /** 0: only the places you set, 1: also the whole screen when the picture holds still */
    var scope: Int
        get() = sp.getInt("scope", 0)
        set(v) = sp.edit().putInt("scope", v).apply()

    /** fast mode: show on the first read and look at the screen more often */
    var fast: Boolean
        get() = sp.getBoolean("fast", false)
        set(v) = sp.edit().putBoolean("fast", v).apply()

    /** enlarge + add contrast before reading (better for small text, a bit slower) */
    var boost: Boolean
        get() = sp.getBoolean("boost", false)
        set(v) = sp.edit().putBoolean("boost", v).apply()

    var floatBtn: Boolean
        get() = sp.getBoolean("float", true)
        set(v) = sp.edit().putBoolean("float", v).apply()

    var keepOn: Boolean
        get() = sp.getBoolean("keepon", true)
        set(v) = sp.edit().putBoolean("keepon", v).apply()

    var areasJson: String?
        get() = sp.getString("areas", null)
        set(v) = sp.edit().putString("areas", v).apply()

    var areasVersion: Int
        get() = sp.getInt("areasv", 0)
        set(v) = sp.edit().putInt("areasv", v).apply()

    companion object {
        const val DEFAULT_GLOSSARY =
            "# كل سطر: كلمة تفضل زي ما هي، أو كلمة = ترجمتها\n" +
                "Paradise Taxi\nVice City\nLeonida\nLucia\nJason\n"
    }
}

/** What the screen shows about the running service. */
object Status {
    @Volatile var running = false
    @Volatile var line = "جاهز"
    @Volatile var last = ""
    @Volatile var listener: (() -> Unit)? = null
    private val main = Handler(Looper.getMainLooper())

    fun set(text: String) {
        line = text
        main.post { listener?.invoke() }
    }

    fun seen(text: String) {
        last = text
        main.post { listener?.invoke() }
    }

    fun markRunning(on: Boolean) {
        running = on
        main.post { listener?.invoke() }
    }
}
