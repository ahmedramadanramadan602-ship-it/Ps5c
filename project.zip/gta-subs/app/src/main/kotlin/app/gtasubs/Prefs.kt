package app.gtasubs

import android.content.Context
import android.os.Handler
import android.os.Looper

class Prefs(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("p", Context.MODE_PRIVATE)

    /** 0.6 .. 1.8 */
    var fontScale: Float
        get() = sp.getFloat("fs", 1.0f)
        set(v) = sp.edit().putFloat("fs", v).apply()

    /** 0: 16:9 with bars, 1: full screen */
    var aspect: Int
        get() = sp.getInt("aspect", 0)
        set(v) = sp.edit().putInt("aspect", v).apply()

    fun areaOn(id: String): Boolean = sp.getBoolean("a_$id", true)
    fun setAreaOn(id: String, on: Boolean) = sp.edit().putBoolean("a_$id", on).apply()
}

/** What the screen shows about the running service. */
object Status {
    @Volatile var running = false
    @Volatile var line = "جاهز"
    @Volatile var last = ""
    @Volatile var listener: (() -> Unit)? = null
    private val main = Handler(Looper.getMainLooper())

    fun set(text: String) {
        line = text
        main.post { listener?.invoke() }
    }

    fun seen(text: String) {
        last = text
        main.post { listener?.invoke() }
    }

    fun markRunning(on: Boolean) {
        running = on
        main.post { listener?.invoke() }
    }
}
