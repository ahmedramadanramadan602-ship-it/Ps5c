package app.gtasubs

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Words that must stay as they are, or be translated a fixed way. One per line. */
object Glossary {
    class Entry(val src: String, val dst: String?)

    fun parse(text: String): List<Entry> {
        val out = ArrayList<Entry>()
        for (raw in text.lines()) {
            val line = raw.trim()
            if (line.isEmpty() || line.startsWith("#")) continue
            val i = line.indexOf('=')
            if (i < 0) {
                out.add(Entry(line, null))
            } else {
                val s = line.substring(0, i).trim()
                val d = line.substring(i + 1).trim()
                if (s.isNotEmpty()) out.add(Entry(s, if (d.isEmpty()) null else d))
            }
        }
        return out
    }
}

/** The AI translator (Gemini, over the internet). Only the text is sent, never the picture. */
object Ai {
    class AiException(msg: String) : Exception(msg)

    @Volatile
    private var blockedUntil = 0L

    fun available(p: Prefs): Boolean =
        p.engine == 1 && p.apiKey.isNotBlank() && System.currentTimeMillis() >= blockedUntil

    private fun systemPrompt(p: Prefs, batch: Boolean): String {
        val g = Glossary.parse(p.glossary)
        val keep = g.filter { it.dst == null }.map { it.src }
        val fixed = g.filter { it.dst != null }
        return buildString {
            append("You are a professional video game localizer. Translate English game subtitles and on-screen text into Arabic. ")
            if (p.dialect == 1) {
                append("Use natural Egyptian Arabic (عامية مصرية) for spoken dialogue, and short clear wording for menus and instructions. ")
            } else {
                append("Use clear, natural Modern Standard Arabic suitable for subtitles. ")
            }
            append("Keep lines short and easy to read quickly. The text comes from OCR and may contain small recognition mistakes: fix them from context. ")
            append("Keep personal names, brand names and place names in English unless a glossary entry says otherwise. ")
            if (keep.isNotEmpty()) append("Never translate these terms: ${keep.joinToString(", ")}. ")
            if (fixed.isNotEmpty()) {
                append("Use these exact translations: ${fixed.joinToString("; ") { "${it.src} => ${it.dst}" }}. ")
            }
            if (batch) {
                append("Reply with one line per input in the form N|translation using the same numbers, and nothing else.")
            } else {
                append("Output only the Arabic translation: no quotes, notes or explanations.")
            }
        }
    }

    private fun call(p: Prefs, system: String, user: String, maxTokens: Int): String {
        val model = p.model.trim().ifEmpty { Prefs.DEFAULT_MODEL }
        return try {
            callOnce(p, model, system, user, maxTokens, true)
        } catch (e: AiException) {
            val m = e.message ?: ""
            when {
                // some models refuse the "no thinking" setting: try once more without it
                m.startsWith("HTTP 400") -> callOnce(p, model, system, user, maxTokens, false)
                // a model that was switched off: fall back to the current one
                m.startsWith("HTTP 404") && model != Prefs.DEFAULT_MODEL ->
                    callOnce(p, Prefs.DEFAULT_MODEL, system, user, maxTokens, true)
                else -> throw e
            }
        }
    }

    private fun callOnce(p: Prefs, model: String, system: String, user: String, maxTokens: Int, thinking: Boolean): String {
        if (p.apiKey.isBlank()) throw AiException("حط مفتاح الـAPI الأول")
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
        val body = JSONObject()
        body.put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
        body.put(
            "contents",
            JSONArray().put(
                JSONObject().put("role", "user")
                    .put("parts", JSONArray().put(JSONObject().put("text", user))),
            ),
        )
        val gen = JSONObject().put("temperature", 0.2).put("maxOutputTokens", maxTokens)
        // no "thinking": it only adds delay for a plain translation
        if (thinking && model.contains("2.5-flash")) gen.put("thinkingConfig", JSONObject().put("thinkingBudget", 0))
        body.put("generationConfig", gen)

        val c = url.openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 3000
            c.readTimeout = 7000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("x-goog-api-key", p.apiKey.trim())
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            if (code == 429) {
                blockedUntil = System.currentTimeMillis() + 30_000
                throw AiException("وصلت للحد المجاني (429)، هرجع للأوفلاين شوية")
            }
            if (code !in 200..299) {
                val err = c.errorStream?.bufferedReader()?.readText() ?: ""
                throw AiException("HTTP $code ${err.take(400)}")
            }
            val txt = c.inputStream.bufferedReader().use { it.readText() }
            val parts = JSONObject(txt).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts")
            val sb = StringBuilder()
            for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
            return sb.toString().trim()
        } finally {
            c.disconnect()
        }
    }

    /** One line, with the last lines as context. Throws when it can't. */
    fun translate(p: Prefs, text: String, context: List<String>): String {
        val user = if (context.isEmpty()) {
            text
        } else {
            "Previous lines (context only, do not translate):\n" +
                context.joinToString("\n") { "- $it" } + "\n\nTranslate this line:\n" + text
        }
        val r = call(p, systemPrompt(p, false), user, 400).trim().trim('"', '«', '»')
        if (r.isEmpty()) throw AiException("رد فاضي")
        return r
    }

    /** Many lines in one request (the whole-screen mode). A null means that line failed. */
    fun translateBatch(p: Prefs, texts: List<String>): List<String?> {
        val user = texts.mapIndexed { i, t -> "${i + 1}|$t" }.joinToString("\n")
        val r = call(p, systemPrompt(p, true), user, 1500)
        val out = arrayOfNulls<String>(texts.size)
        val re = Regex("^\\s*(\\d+)\\s*\\|\\s*(.+)$")
        for (line in r.lines()) {
            val m = re.find(line) ?: continue
            val idx = m.groupValues[1].toInt() - 1
            if (idx in out.indices) out[idx] = m.groupValues[2].trim()
        }
        return out.toList()
    }
}
