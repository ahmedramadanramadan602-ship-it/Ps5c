package app.gtasubs

import kotlin.math.abs

object Txt {
    /** Letters and digits only, lower case: for comparing two OCR reads. */
    fun norm(s: String): String = s.lowercase().filter { it.isLetterOrDigit() }

    /** The same text, allowing a few letters the OCR read differently (about 10%). */
    fun same(a: String, b: String): Boolean {
        if (a == b) return true
        val m = maxOf(a.length, b.length)
        if (m == 0) return true
        if (abs(a.length - b.length) > m / 8 + 1) return false
        return lev(a, b) <= m / 10
    }

    private fun lev(a: String, b: String): Int {
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            for (j in 1..b.length) {
                val c = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + c)
            }
            val t = prev; prev = cur; cur = t
        }
        return prev[b.length]
    }

    /** Mostly English letters: not noise, not Arabic that this app drew itself. */
    fun latinOk(s: String): Boolean {
        val letters = s.count { it in 'a'..'z' || it in 'A'..'Z' }
        val total = s.count { !it.isWhitespace() }
        return letters >= 3 && letters * 100 >= total * 60
    }
}
